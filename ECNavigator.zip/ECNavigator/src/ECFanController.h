

BOOL fan_update(const unsigned char value);

