

int GetCPULoad();