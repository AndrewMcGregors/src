
LRESULT ec_message(HWND hwindow, int item, UINT message, WPARAM w, LPARAM l);

LRESULT ec_note(char *c);


