


HBRUSH  load_bkground(char file_bmp[24]);

HBITMAP load_bkground2(char file_bmp[24]);